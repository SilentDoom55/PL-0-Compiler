Homework #4
by Cameron Bernard

Note: all commands are ran without the surrounding parenthesis

Running the program:
1. Compile the program by navigating to it within a command line and executing the command "make".
2. Run the file by using "./a.out FILENAME.txt" where FILENAME.txt is the name of the input file.
2a. You can add -l -a and -v to the end of the previous command to show various outputs. Ex: "./a.out FILENAME.txt -l -a -v"

The code should run using these specifications and output its results to the commandline